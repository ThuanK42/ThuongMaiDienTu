package io.github.tubean.myspringcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyspringcrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyspringcrudApplication.class, args);
    }
}
